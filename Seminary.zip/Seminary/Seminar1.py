# a = int(input('Введитие a '))
# b = int(input('Введитие b '))
# if a ** 2 == b or b ** 2 == a:
#     print('Да')
# else:
#     print('Нет')

# max_ = float('-inf') # минус бесконечность
# for i in range(5):
#     mass = int(input())
#     if mass > max_:
#         max_ = mass
# print('Большее - ',max_)

# max_ = float('-inf')
# for i in range(1, 6):
#     value = int(input(f'введите {i} элемент: '))
#     max_ = value if (max_ < value) else max_
# print(f'максимальное число = {max_}')

#print('', sep='_', end=' ')

# number = int(input())
# start = -number

# while start <= number:
#     print(start, end=' ')
#     start += 1

# number = int(input())
# for n in range(-number, number + 1):
#     print(n, end=' ')

# a = float(input())
# print( int(a * 10) % 10)

# print('\\n')