'''
Задача: Создать информационную систему позволяющую работать
с сотрудниками некой компании \ студентами вуза \ учениками
школы
'''

# from datetime import datetime
# a = datetime.now()
# print(a.strftime('%d.%m.%Y'))
# b = datetime.strptime('22.02.1998', '%d.%m.%Y')
# print(b)

